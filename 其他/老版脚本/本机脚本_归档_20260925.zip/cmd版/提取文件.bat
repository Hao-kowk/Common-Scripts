@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0��ȡ�ļ�_v1.0.ps1" %*
echo.
pause
